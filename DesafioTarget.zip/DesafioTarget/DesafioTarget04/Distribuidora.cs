﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesafioTarget04
{
    public class Distribuidora
    {
        public string Estado { get; private set; }
        public double Valor { get; private set; }

        public Distribuidora(string estado, double valor)
        {
            Estado = estado;
            Valor = valor;
        }
    }
}
