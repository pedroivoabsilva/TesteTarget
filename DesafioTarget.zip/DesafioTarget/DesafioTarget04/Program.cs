﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DesafioTarget04
{
    class Program
    {
        static void Main(string[] args)
        {
            Distribuidora[] distribuidoras = {

                new Distribuidora("SP", 67836.43),
                new Distribuidora("RJ", 36678.66),
                new Distribuidora("MG", 29229.88),
                new Distribuidora("ES", 27165.48),
                new Distribuidora("Outros", 19849.53) 
            };
            double total = distribuidoras.Sum(item => item.Valor);
            
            foreach (var distribuidora in distribuidoras)
            {
                double porcentagem = (distribuidora.Valor / total) * 100;
                Console.WriteLine($"A distribuidora tem {porcentagem.ToString("F2")}% dentro no estado de {distribuidora.Estado}");
            }
        }
    }
}
