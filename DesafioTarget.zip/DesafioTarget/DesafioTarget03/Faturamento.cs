﻿namespace DesafioTarget03
{
    public class Faturamento
    {
        public int dia { get; set; }
        public double valor { get; set; }
    }
}
