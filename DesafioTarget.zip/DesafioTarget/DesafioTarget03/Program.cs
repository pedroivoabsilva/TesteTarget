﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace DesafioTarget03
{
    class Program
    {
        static void Main(string[] args)
        {
            //Obtendo dados do json
            string arquivo = "dados.json";
            string jsonString = File.ReadAllText(arquivo);
            List<Faturamento> faturamentos = JsonConvert.DeserializeObject<List<Faturamento>>(jsonString);

            // Variaveis para calculo faturamento
            double menorFatutamento = double.MaxValue, maiorFaturamento = 0, total=0, mediaMensal = 0, QtdDiaFaturamentoSuperiorMedia=0;
            int qtdDias = 0;

            //Calculo menor faturamento
            for (int i = 0; i < faturamentos.Count; i++)
            {
                //Calculo menor faturamento
                if (menorFatutamento > faturamentos[i].valor && faturamentos[i].valor != 0)
                {
                    menorFatutamento = faturamentos[i].valor;
                }

                //Calculo maior faturamento
                if (maiorFaturamento < faturamentos[i].valor)
                {
                    maiorFaturamento = faturamentos[i].valor;
                }

                //Calculo da media
                if (faturamentos[i].valor != 0)
                {
                    total = total + faturamentos[i].valor;
                    qtdDias++;
                }
                mediaMensal = total / qtdDias;

                //Calculo quantidade de dias
                if (faturamentos[i].valor > mediaMensal)
                    QtdDiaFaturamentoSuperiorMedia++;
                

            }
            
            //Resposta
            Console.WriteLine($"Menor faturamento é de R${menorFatutamento}");
            Console.WriteLine($"Maior faturamento é de R${maiorFaturamento}");
            Console.WriteLine($"{QtdDiaFaturamentoSuperiorMedia} dias tiveram o faturamento maior que a média mensal");

        }
    }
}
