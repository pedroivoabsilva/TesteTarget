﻿using System;

namespace DesafioTarget02
{
    class Program
    {
        static void Main(string[] args)
        {
            int numeroAnterior = 0, numeroAtual = 1, EntradaNumero, Fibonacci = 0;
            Console.Write("Digite o numero que deseja consultar: ");
            EntradaNumero = int.Parse(Console.ReadLine());
            while (Fibonacci < EntradaNumero)
            {
                Fibonacci = numeroAnterior + numeroAtual;
                numeroAtual = numeroAnterior;
                numeroAnterior = Fibonacci;
            }
            if (EntradaNumero == Fibonacci)
                Console.WriteLine("O numero digitado pertence a sequencia fibonacci");
            else
                Console.WriteLine("O numero digitado não pertence a sequencia fibonacci");
        }
    }
}
