﻿using System;
using System.Collections.Generic;

namespace DesafioTarget05
{
    class Program
    {
        static void Main(string[] args)
        {
            string palavra = "paralelepipedo";
            string palavraInvertida = string.Empty;
            int i;
            for(i = palavra.Length-1;i>=0;i--)
            {
                palavraInvertida += palavra[i];
            }
            Console.WriteLine(palavra);
            Console.WriteLine(palavraInvertida);
           
        }
    }
}
